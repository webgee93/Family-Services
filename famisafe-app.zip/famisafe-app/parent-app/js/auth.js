import { 
    createUserWithEmailAndPassword, 
    signInWithEmailAndPassword, 
    signOut,
    onAuthStateChanged 
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { 
    getFirestore, 
    doc, 
    setDoc, 
    getDoc 
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// Show/Hide Forms
function showSignup() {
    document.getElementById('loginForm').classList.add('hidden');
    document.getElementById('signupForm').classList.remove('hidden');
}

function showLogin() {
    document.getElementById('signupForm').classList.add('hidden');
    document.getElementById('loginForm').classList.remove('hidden');
}

// Login Function
async function login() {
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const errorElement = document.getElementById('loginError');
    
    errorElement.textContent = '';
    
    try {
        const userCredential = await signInWithEmailAndPassword(window.firebaseAuth, email, password);
        const user = userCredential.user;
        
        // Store user data
        localStorage.setItem('user', JSON.stringify({
            uid: user.uid,
            email: user.email
        }));
        
        // Show dashboard
        showDashboard();
        
    } catch (error) {
        errorElement.textContent = getErrorMessage(error.code);
    }
}

// Signup Function
async function signup() {
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const phone = document.getElementById('signupPhone').value;
    const errorElement = document.getElementById('signupError');
    
    errorElement.textContent = '';
    
    try {
        const userCredential = await createUserWithEmailAndPassword(window.firebaseAuth, email, password);
        const user = userCredential.user;
        
        // Create user profile in Firestore
        await setDoc(doc(window.firestoreDB, "parents", user.uid), {
            name: name,
            email: email,
            phone: phone,
            createdAt: new Date().toISOString(),
            children: []
        });
        
        // Store user data
        localStorage.setItem('user', JSON.stringify({
            uid: user.uid,
            email: user.email,
            name: name
        }));
        
        // Show dashboard
        showDashboard();
        
    } catch (error) {
        errorElement.textContent = getErrorMessage(error.code);
    }
}

// Logout Function
async function logout() {
    try {
        await signOut(window.firebaseAuth);
        localStorage.removeItem('user');
        showAuthScreen();
    } catch (error) {
        console.error('Logout error:', error);
    }
}

// Show Dashboard
function showDashboard() {
    document.getElementById('authScreen').classList.remove('active');
    document.getElementById('dashboardScreen').classList.add('active');
    document.getElementById('userName').textContent = JSON.parse(localStorage.getItem('user'))?.name || 'User';
    loadChildren();
}

// Show Auth Screen
function showAuthScreen() {
    document.getElementById('dashboardScreen').classList.remove('active');
    document.getElementById('authScreen').classList.add('active');
    document.getElementById('loginForm').classList.remove('hidden');
    document.getElementById('signupForm').classList.add('hidden');
}

// Error Messages
function getErrorMessage(errorCode) {
    const messages = {
        'auth/invalid-email': 'Invalid email address',
        'auth/user-disabled': 'Account disabled',
        'auth/user-not-found': 'Account not found',
        'auth/wrong-password': 'Incorrect password',
        'auth/email-already-in-use': 'Email already in use',
        'auth/weak-password': 'Password is too weak',
        'auth/network-request-failed': 'Network error'
    };
    return messages[errorCode] || 'An error occurred';
}

// Check auth state on load
onAuthStateChanged(window.firebaseAuth, (user) => {
    if (user) {
        showDashboard();
    } else {
        showAuthScreen();
    }
});

// Make functions globally available
window.login = login;
window.signup = signup;
window.logout = logout;
window.showSignup = showSignup;
window.showLogin = showLogin;