// Simple map implementation
function initMap() {
    const mapElement = document.getElementById('map');
    mapElement.innerHTML = `
        <div style="text-align: center; padding: 50px;">
            <h3>Live Location Tracking</h3>
            <p>Map will show real-time locations of children</p>
            <p>For full map functionality, integrate Google Maps API</p>
            <button onclick="showDemoLocations()" class="btn-primary">
                Show Demo Locations
            </button>
        </div>
    `;
}

// Demo locations
function showDemoLocations() {
    document.getElementById('map').innerHTML = `
        <div style="padding: 20px;">
            <h4>Demo Locations</h4>
            <div style="margin: 20px 0;">
                <p>📍 Child 1: School (28.6139° N, 77.2090° E)</p>
                <p>📍 Child 2: Home (28.6100° N, 77.2000° E)</p>
            </div>
            <p><em>Note: Real Google Maps requires API key</em></p>
        </div>
    `;
    
    // Update location list
    document.getElementById('locationList').innerHTML = `
        <div class="location-card">
            <h4>Child 1 - School</h4>
            <p>📍 28.6139° N, 77.2090° E</p>
            <p>🕒 Last updated: Just now</p>
        </div>
        <div class="location-card">
            <h4>Child 2 - Home</h4>
            <p>📍 28.6100° N, 77.2000° E</p>
            <p>🕒 Last updated: 5 min ago</p>
        </div>
    `;
}

// Make functions global
window.initMap = initMap;
window.showDemoLocations = showDemoLocations;

// Add location card CSS
const style = document.createElement('style');
style.textContent = `
    .location-card {
        background: white;
        padding: 15px;
        margin: 10px 0;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .child-item {
        background: white;
        padding: 15px;
        margin: 10px 0;
        border-radius: 8px;
        box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
`;
document.head.appendChild(style);