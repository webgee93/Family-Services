import { 
    getFirestore, 
    collection, 
    doc, 
    setDoc, 
    getDoc, 
    updateDoc,
    arrayUnion,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

// Show section
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remove active from nav links
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId + 'Section').classList.add('active');
    
    // Activate nav link
    document.querySelector(`[onclick*="${sectionId}"]`).classList.add('active');
    
    // Load section data
    if (sectionId === 'location') {
        initMap();
    }
}

// Add child modal
function addChild() {
    document.getElementById('addChildModal').classList.remove('hidden');
}

function closeModal() {
    document.getElementById('addChildModal').classList.add('hidden');
}

// Save child
async function saveChild() {
    const name = document.getElementById('childName').value;
    const age = document.getElementById('childAge').value;
    const deviceId = document.getElementById('childDeviceId').value;
    
    if (!name || !deviceId) {
        alert('Please fill required fields');
        return;
    }
    
    const user = JSON.parse(localStorage.getItem('user'));
    
    try {
        // Create child document
        await setDoc(doc(window.firestoreDB, "children", deviceId), {
            name: name,
            age: age || null,
            deviceId: deviceId,
            parentId: user.uid,
            createdAt: new Date().toISOString()
        });
        
        // Add to parent's children array
        await updateDoc(doc(window.firestoreDB, "parents", user.uid), {
            children: arrayUnion(deviceId)
        });
        
        closeModal();
        alert('Child added successfully!');
        loadChildren();
        
    } catch (error) {
        alert('Error: ' + error.message);
    }
}

// Load children
async function loadChildren() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) return;
    
    try {
        const parentDoc = await getDoc(doc(window.firestoreDB, "parents", user.uid));
        if (parentDoc.exists()) {
            const children = parentDoc.data().children || [];
            document.getElementById('childrenCount').textContent = children.length;
            
            const container = document.getElementById('childrenContainer');
            container.innerHTML = '';
            
            if (children.length === 0) {
                container.innerHTML = '<p class="empty-message">No children added yet</p>';
                return;
            }
            
            for (const childId of children) {
                const childDoc = await getDoc(doc(window.firestoreDB, "children", childId));
                if (childDoc.exists()) {
                    const child = childDoc.data();
                    const childElement = document.createElement('div');
                    childElement.className = 'child-item';
                    childElement.innerHTML = `
                        <h4>${child.name}</h4>
                        <p>Device: ${child.deviceId}</p>
                        <button onclick="trackChild('${child.deviceId}')">Track</button>
                    `;
                    container.appendChild(childElement);
                }
            }
        }
    } catch (error) {
        console.error('Error loading children:', error);
    }
}

// Generate child code
function generateCode() {
    const code = 'FS' + Date.now() + Math.random().toString(36).substr(2, 6).toUpperCase();
    document.getElementById('codeDisplay').innerHTML = `
        <p><strong>Child Code:</strong> ${code}</p>
        <p>Share this with child's device</p>
    `;
}

// Track child
function trackChild(deviceId) {
    showSection('location');
    // Center map on child
    console.log('Tracking:', deviceId);
}

// Update time limit
function updateLimit() {
    const limit = document.getElementById('timeLimit').value;
    document.getElementById('limitDisplay').textContent = limit + ' hours';
    alert('Daily limit set to ' + limit + ' hours');
}

// Make functions global
window.showSection = showSection;
window.addChild = addChild;
window.closeModal = closeModal;
window.saveChild = saveChild;
window.generateCode = generateCode;
window.trackChild = trackChild;
window.updateLimit = updateLimit;
window.loadChildren = loadChildren;

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    // Set up time limit slider
    const slider = document.getElementById('timeLimit');
    const display = document.getElementById('limitDisplay');
    slider.addEventListener('input', () => {
        display.textContent = slider.value + ' hours';
    });
    
    // Load children
    loadChildren();
});