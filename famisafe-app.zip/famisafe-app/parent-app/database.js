// js/database.js
import { getFirestore, collection, addDoc, setDoc, doc, getDoc, updateDoc, onSnapshot, query, where } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-firestore.js";

const db = getFirestore(app);

// Create Parent Profile
async function createParentProfile(uid, email) {
    try {
        await setDoc(doc(db, "parents", uid), {
            email: email,
            createdAt: new Date().toISOString(),
            children: [],
            settings: {
                alerts: true,
                notifications: true,
                autoBlock: false
            }
        });
        console.log("Parent profile created");
    } catch (error) {
        console.error("Error creating parent profile:", error);
    }
}

// Add Child Device
async function addChildDevice(parentId, childName, deviceId) {
    try {
        const childRef = doc(db, "children", deviceId);
        await setDoc(childRef, {
            parentId: parentId,
            name: childName,
            deviceId: deviceId,
            createdAt: new Date().toISOString(),
            isActive: true,
            lastSeen: new Date().toISOString()
        });
        
        // Add to parent's children array
        const parentRef = doc(db, "parents", parentId);
        await updateDoc(parentRef, {
            children: firebase.firestore.FieldValue.arrayUnion(deviceId)
        });
        
        console.log("Child device added");
    } catch (error) {
        console.error("Error adding child device:", error);
    }
}