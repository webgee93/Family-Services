// Shared Firebase Configuration
export const firebaseConfig = {
    apiKey: "AIzaSyAl86DCvIZcZGbZfkA_RTUA_R1-Z5wtwKU",
    authDomain: "family-protection-app.firebaseapp.com",
    databaseURL: "https://family-protection-app-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "family-protection-app",
    storageBucket: "family-protection-app.firebasestorage.app",
    messagingSenderId: "104693645826",
    appId: "1:104693645826:web:8cf0a1d362feff988f9d1b"
};